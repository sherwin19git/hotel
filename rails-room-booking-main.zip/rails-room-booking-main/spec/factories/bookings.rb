FactoryBot.define do
  factory :booking_1, class: Booking do
    num_guests { 3 }
  end
end
