Payify.setup do |config|
  config.currency = ENV["PAYMENT_CURRENCY"]
end
