# frozen_string_literal: true

DOMAIN_NAME = 'https://rails-room-booking.com'
