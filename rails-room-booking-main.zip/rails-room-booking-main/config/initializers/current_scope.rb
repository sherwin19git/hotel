module CurrentScope
  thread_mattr_accessor :user_id
end
